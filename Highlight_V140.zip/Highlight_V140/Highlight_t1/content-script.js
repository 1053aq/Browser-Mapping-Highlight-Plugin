// 存储当前的映射关系
let currentMappings = [];
// 缓存正则表达式
let regexCache = new Map();
// 记录每组关键词的实际匹配情况
let groupMatchStatus = new Map();
// 标记是否正在处理，避免重复执行
let isProcessing = false;
// DOM变化观察器实例
let mutationObserver = null;
// 用于节流的计时器
let highlightThrottleTimer = null;

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateData') {
        // 重置状态
        resetHighlighterState();
        
        // 更新数据
        currentMappings = request.mappings || [];
        
        // 立即应用高亮
        if (currentMappings.length > 0) {
            applyHighlightsImmediately();
        } else {
            removeAllHighlights();
        }
        
        sendResponse({ status: "success" });
    }
});

// 重置高亮器状态
function resetHighlighterState() {
    if (isProcessing && highlightThrottleTimer) {
        clearTimeout(highlightThrottleTimer);
        highlightThrottleTimer = null;
    }
    
    regexCache.clear();
    groupMatchStatus.clear();
    currentMappings.forEach((_, index) => {
        groupMatchStatus.set(index, {
            hasMatchingKeyword: false,
            keywordMatches: new Set()
        });
    });
}

// 初始化函数
function initHighlighter() {
    chrome.storage.local.get(['mappings'], (data) => {
        if (data.mappings && Array.isArray(data.mappings)) {
            currentMappings = data.mappings.map(mapping => ({
                searchTerms: mapping.searchTerms || [],
                mappedTerms: mapping.mappedTerms || [],
                searchColor: mapping.searchColor || '#fff34d',
                mappedColor: mapping.mappedColor || '#4dd0e1'
            }));
        }
        
        // 初始化匹配状态
        currentMappings.forEach((_, index) => {
            groupMatchStatus.set(index, {
                hasMatchingKeyword: false,
                keywordMatches: new Set()
            });
        });
        
        // 启动DOM变化监听
        startMutationObserver();
        
        // 初始高亮
        if (currentMappings.length > 0) {
            // 等待DOM准备就绪
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', applyHighlightsImmediately);
            } else {
                applyHighlightsImmediately();
            }
        }
    });
}

// 启动DOM变化观察器
function startMutationObserver() {
    if (mutationObserver) {
        mutationObserver.disconnect();
    }
    
    const config = {
        childList: true,
        subtree: true,
        characterData: true
    };
    
    mutationObserver = new MutationObserver((mutations) => {
        // 使用节流处理
        if (!highlightThrottleTimer) {
            highlightThrottleTimer = setTimeout(() => {
                processDOMChanges(mutations);
                highlightThrottleTimer = null;
            }, 100);
        }
    });
    
    // 开始观察
    const observeTarget = () => {
        const target = document.body || document.documentElement;
        if (target) {
            mutationObserver.observe(target, config);
        } else {
            setTimeout(observeTarget, 100);
        }
    };
    
    observeTarget();
}

// 处理DOM变化
function processDOMChanges(mutations) {
    if (currentMappings.length === 0 || isProcessing) return;
    
    // 清除现有高亮
    removeAllHighlights();
    // 重置匹配状态
    resetMatchStatus();
    
    // 重新应用高亮
    applyHighlightsImmediately();
}

// 重置匹配状态
function resetMatchStatus() {
    currentMappings.forEach((_, index) => {
        groupMatchStatus.set(index, {
            hasMatchingKeyword: false,
            keywordMatches: new Set()
        });
    });
}

// 立即应用高亮
function applyHighlightsImmediately() {
    if (currentMappings.length === 0 || isProcessing) return;
    
    isProcessing = true;
    
    try {
        // 1. 先处理所有关键词，标记哪些组有匹配的关键词
        identifyMatchingKeywordGroups();
        
        // 2. 只处理有匹配关键词的组的高亮词
        const termsToHighlight = getTermsToHighlight();
        
        // 3. 应用高亮
        const textNodes = [];
        walkTextNodes(document.body, (node) => textNodes.push(node));
        
        textNodes.forEach(textNode => {
            processTextNode(textNode, termsToHighlight);
        });
        
    } catch (error) {
        console.error('高亮处理错误:', error);
    } finally {
        isProcessing = false;
    }
}

// 识别有匹配关键词的组
function identifyMatchingKeywordGroups() {
    // 收集所有文本内容
    const textContent = document.body.innerText.toLowerCase();
    
    // 检查每组关键词
    currentMappings.forEach((mapping, groupIndex) => {
        const matchStatus = groupMatchStatus.get(groupIndex);
        
        // 检查该组的每个关键词
        mapping.searchTerms.forEach(term => {
            if (term && textContent.includes(term.toLowerCase())) {
                matchStatus.hasMatchingKeyword = true;
                matchStatus.keywordMatches.add(term.toLowerCase());
            }
        });
        
        groupMatchStatus.set(groupIndex, matchStatus);
    });
}

// 获取所有需要高亮的词（仅包括有匹配关键词的组）
function getTermsToHighlight() {
    const termsToHighlight = [];
    
    currentMappings.forEach((mapping, groupIndex) => {
        const matchStatus = groupMatchStatus.get(groupIndex);
        
        // 只处理有匹配关键词的组
        if (matchStatus.hasMatchingKeyword) {
            // 添加检索词
            mapping.searchTerms.forEach(term => {
                if (term) {
                    termsToHighlight.push({
                        term: term,
                        type: 'search-term',
                        group: groupIndex,
                        color: mapping.searchColor,
                        length: term.length
                    });
                }
            });
            
            // 添加关联高亮词
            mapping.mappedTerms.forEach(term => {
                if (term) {
                    termsToHighlight.push({
                        term: term,
                        type: 'mapped-term',
                        group: groupIndex,
                        color: mapping.mappedColor,
                        length: term.length
                    });
                }
            });
        }
    });
    
    // 按长度排序，长词优先
    return termsToHighlight.sort((a, b) => b.length - a.length);
}

// 清除所有高亮
function removeAllHighlights() {
    const highlights = document.querySelectorAll('.multi-find-highlight');
    highlights.forEach(highlight => {
        const parent = highlight.parentNode;
        if (parent) {
            // 将高亮元素的内容移回父节点
            while (highlight.firstChild) {
                parent.insertBefore(highlight.firstChild, highlight);
            }
            parent.removeChild(highlight);
        }
    });
}

// 处理单个文本节点
function processTextNode(textNode, termsToHighlight) {
    // 跳过已经处理过的节点
    if (textNode.parentNode && textNode.parentNode.classList.contains('multi-find-highlight')) {
        return;
    }
    
    const text = textNode.nodeValue;
    let lastIndex = 0;
    let matched = false;
    let fragments = [];
    
    termsToHighlight.forEach(({ term, type, group, color }) => {
        if (!term || lastIndex >= text.length) return;
        
        // 验证该组确实有匹配的关键词
        const matchStatus = groupMatchStatus.get(group);
        if (!matchStatus || !matchStatus.hasMatchingKeyword) {
            return;
        }
        
        let regex;
        const cacheKey = `${group}-${term}-${type}`;
        
        if (regexCache.has(cacheKey)) {
            regex = regexCache.get(cacheKey);
        } else {
            regex = new RegExp(escapeRegExp(term), 'gi');
            regexCache.set(cacheKey, regex);
        }
        
        regex.lastIndex = lastIndex;
        
        let match;
        while ((match = regex.exec(text)) !== null) {
            const [matchedText] = match;
            const start = match.index;
            const end = start + matchedText.length;
            
            if (start >= lastIndex && end <= text.length) {
                matched = true;
                
                if (start > lastIndex) {
                    fragments.push(document.createTextNode(text.substring(lastIndex, start)));
                }
                
                const span = document.createElement('span');
                span.className = `multi-find-highlight ${type} group-${group}`;
                span.textContent = matchedText;
                span.style.backgroundColor = color;
                span.style.boxShadow = `0 0 0 1px ${color}`;
                span.style.fontFamily = 'inherit';
                span.style.fontSize = 'inherit';
                span.style.lineHeight = 'inherit';
                
                fragments.push(span);
                lastIndex = end;
                regex.lastIndex = lastIndex;
            } else {
                break;
            }
        }
    });
    
    if (lastIndex < text.length) {
        fragments.push(document.createTextNode(text.substring(lastIndex)));
    }
    
    if (matched && fragments.length > 0) {
        const fragment = document.createDocumentFragment();
        fragments.forEach(node => fragment.appendChild(node));
        textNode.parentNode.replaceChild(fragment, textNode);
    }
}

// 遍历文本节点
function walkTextNodes(node, callback) {
    if (node.nodeType === Node.COMMENT_NODE) return;
    
    if (node.nodeType === Node.ELEMENT_NODE) {
        // 跳过不需要处理的元素
        if (node.classList.contains('multi-find-highlight') || 
            ['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'SVG', 'CANVAS'].includes(node.tagName)) {
            return;
        }
        
        if (node.hasAttribute('data-multi-find-ignore')) {
            return;
        }
    }
    
    if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== '') {
        callback(node);
        return;
    }
    
    let child = node.firstChild;
    while (child) {
        const nextChild = child.nextSibling;
        walkTextNodes(child, callback);
        child = nextChild;
    }
}

// 正则转义
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// 初始化
initHighlighter();
    